import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
import { jwtVerify } from 'jose';

export async function middleware(request: NextRequest) {
    const { pathname } = request.nextUrl;

    const token = request.cookies.get('token')?.value;

    let user = null;

    if (token) {
        try {
            const secret = new TextEncoder().encode(process.env.JWT_SECRET);
            const { payload } = await jwtVerify(token, secret);
            user = payload;
        } catch (err) {
            user = null;
        }
    }

    const protectedRoutes = ['/platform', '/dashboard'];
    const authRoutes = ['/login', '/signup'];

    if (protectedRoutes.some(route => pathname.startsWith(route))) {
        if (!user) {
            return NextResponse.redirect(new URL('/login', request.url));
        }
    }

    if (authRoutes.some(route => pathname.startsWith(route))) {
        if (user) {
            return NextResponse.redirect(new URL('/platform', request.url));
        }
    }

    return NextResponse.next();
}

export const config = {
    matcher: ['/platform/:path*', '/dashboard/:path*', '/login', '/signup'],
};
