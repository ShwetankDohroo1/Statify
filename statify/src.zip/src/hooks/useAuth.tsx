import { useCallback } from 'react';
import api from '../lib/api';
import { useAuthStore } from '../store/authStore';

export const useAuth = () => {
    const setUser = useAuthStore((s) => s.setUser);
    const clearAuth = useAuthStore((s) => s.clearAuth);

    const login = useCallback(async (email: string, password: string) => {
        const res = await api.post('/auth/login', { values: { email, password } });
        const { user } = res.data;
        setUser(user || null);
        return res.data;
    }, [setUser]);

    const logout = useCallback(async () => {
        try {
            await api.post('/auth/logout');
        } catch (e) {
        }
        clearAuth();
    }, [clearAuth]);

    const getProfile = useCallback(async () => {
        const res = await api.get('/auth/me');
        setUser(res.data.user || null);
        return res.data;
    }, [setUser]);

    return { login, logout, getProfile };
};