// 'use client';
// import { Canvas } from "@react-three/fiber";
// import { Environment, OrbitControls } from "@react-three/drei";
// import Statify from './statify';
// import React from "react";
// const Statifymodel = () =>{
//     return(
//         <div className="">
//             <Canvas>
//                 <Environment preset="studio"/>
//                 <OrbitControls />
//                 <Statify />
//             </Canvas>
//         </div>
//     )
// }
// export default Statifymodel;