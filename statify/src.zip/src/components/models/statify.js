// import React, { useRef } from 'react'
// import { useGLTF } from '@react-three/drei'

// export function Statify(props) {
//     const { nodes, materials } = useGLTF('/Statify.glb')
//     return (
//         <group {...props} dispose={null}>
//             <mesh
//                 castShadow
//                 receiveShadow
//                 geometry={nodes.Text.geometry}
//                 material={materials['Material.001']}
//                 position={[0.301, 0.687, -0.471]}
//             />
//         </group>
//     )
// }

// useGLTF.preload('/Statify.glb')