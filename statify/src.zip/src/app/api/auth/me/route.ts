import { NextRequest, NextResponse } from "next/server";
import prisma from "lib/prisma";
import { getUserFromToken } from "../../utils/jwtToken";

export async function GET(request: NextRequest) {
    try {
        const user = getUserFromToken(request);

        if (!user) {
            return NextResponse.json(
                { error: "Unauthorized" },
                { status: 401 }
            );
        }

        const dbUser = await prisma.user.findUnique({
            where: { id: user.id },
            select: {
                id: true,
                username: true,
                email: true,
                leetcodeId: true,
                codeforcesId: true,
                gfgId: true,
                githubId: true,
            },
        });

        if (!dbUser) {
            return NextResponse.json(
                { error: "User not found" },
                { status: 404 }
            );
        }

        return NextResponse.json({
            success: true,
            user: dbUser,
        });
    } catch (error: any) {
        console.error("Error fetching user profile:", error);
        return NextResponse.json(
            { error: error.message },
            { status: 500 }
        );
    }
}