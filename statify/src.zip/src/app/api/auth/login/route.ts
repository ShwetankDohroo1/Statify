import { PrismaClient } from "@prisma/client";
import { comparePassword } from "../../utils/comparePassword";
import { generateToken } from "../../utils/jwtToken";
import { NextRequest, NextResponse } from "next/server";

const prisma = new PrismaClient();

async function validateUser(email: string) {
    return await prisma.user.findUnique({
        where: { email },
    });
}

export async function POST(request: NextRequest) {
    try {
        const reqBody = await request.json();
        const { email, password } = reqBody.values;

        const user = await validateUser(email);
        if (!user) {
            return NextResponse.json({ error: "User not found" }, { status: 404 });
        }

        try {
            await comparePassword(password, user.password);
        } catch (error) {
            return NextResponse.json({ error: "Invalid credentials" }, { status: 401 });
        }

        const token = generateToken(user);

        const response = NextResponse.json({
            message: "Login Successfully",
            success: true,
            user: {
                id: user.id,
                username: user.username,
                email: user.email,
                leetcodeId: user.leetcodeId,
                codeforcesId: user.codeforcesId,
                gfgId: user.gfgId,
                githubId: user.githubId,
            },
        });

        response.headers.set(
            "Set-Cookie",
            `token=${token}; HttpOnly; Secure; SameSite=Strict; Max-Age=${30 * 24 * 60 * 60}; Path=/`
        );

        return response;
    } catch (error: any) {
        console.error("Error:", error);
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}