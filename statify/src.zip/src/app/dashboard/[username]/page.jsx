'use client'
import DashBody from "@/components/dashboard/bash-body";
export default function DashBoard() {
    return (
        <div className="h-full w-full">
            <DashBody />
        </div>
    );
}
